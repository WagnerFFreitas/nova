import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { text, voice = "pt-BR-FranciscaNeural", rate = 1.0, pitch = 1.0 } = await request.json()

    if (!process.env.AZURE_SPEECH_KEY || !process.env.AZURE_SPEECH_REGION) {
      return NextResponse.json({ error: "Azure Speech credentials not configured" }, { status: 500 })
    }

    // Construir SSML para controle avançado
    const ssml = `
      <speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="pt-BR">
        <voice name="${voice}">
          <prosody rate="${rate}" pitch="${pitch > 1 ? "+" : ""}${Math.round((pitch - 1) * 50)}%">
            ${text}
          </prosody>
        </voice>
      </speak>
    `

    const response = await fetch(
      `https://${process.env.AZURE_SPEECH_REGION}.tts.speech.microsoft.com/cognitiveservices/v1`,
      {
        method: "POST",
        headers: {
          "Ocp-Apim-Subscription-Key": process.env.AZURE_SPEECH_KEY,
          "Content-Type": "application/ssml+xml",
          "X-Microsoft-OutputFormat": "audio-16khz-128kbitrate-mono-mp3",
          "User-Agent": "NOVA-AI",
        },
        body: ssml,
      },
    )

    if (!response.ok) {
      const error = await response.text()
      console.error("Azure Speech Error:", error)
      return NextResponse.json({ error: "Failed to generate speech" }, { status: response.status })
    }

    const audioBuffer = await response.arrayBuffer()

    return new NextResponse(audioBuffer, {
      headers: {
        "Content-Type": "audio/mpeg",
        "Content-Length": audioBuffer.byteLength.toString(),
      },
    })
  } catch (error) {
    console.error("Azure Speech API Error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
