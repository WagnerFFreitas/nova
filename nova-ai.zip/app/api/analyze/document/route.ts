import { type NextRequest, NextResponse } from "next/server"
import { PDFExtract } from "pdf.js-extract"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get("file") as File

    if (!file) {
      return NextResponse.json({ error: "Nenhum arquivo enviado" }, { status: 400 })
    }

    let extractedText = ""
    const fileInfo = {
      name: file.name,
      size: file.size,
      type: file.type,
      pages: 0,
    }

    // Processar diferentes tipos de documento
    if (file.type === "application/pdf") {
      try {
        const pdfExtract = new PDFExtract()
        const bytes = await file.arrayBuffer()
        const buffer = Buffer.from(bytes)

        const data = await new Promise<any>((resolve, reject) => {
          pdfExtract.extractBuffer(buffer, {}, (err, data) => {
            if (err) reject(err)
            else resolve(data)
          })
        })

        fileInfo.pages = data.pages.length
        extractedText = data.pages.map((page: any) => page.content.map((item: any) => item.str).join(" ")).join("\n\n")
      } catch (pdfError) {
        console.error("Erro ao processar PDF:", pdfError)
        return NextResponse.json({ error: "Erro ao processar PDF" }, { status: 400 })
      }
    } else if (file.type === "text/plain") {
      // Arquivo de texto simples
      extractedText = await file.text()
      fileInfo.pages = 1
    } else if (
      file.type === "application/msword" ||
      file.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    ) {
      // Para documentos Word, seria necessário usar uma biblioteca como mammoth
      // Por simplicidade, retornamos uma mensagem informativa
      extractedText = "Documento Word detectado. Para análise completa, converta para PDF ou texto."
      fileInfo.pages = 1
    } else {
      return NextResponse.json({ error: "Tipo de documento não suportado" }, { status: 400 })
    }

    // Limitar o texto para análise (primeiros 4000 caracteres)
    const textForAnalysis = extractedText.substring(0, 4000)

    // Usar OpenAI para análise do conteúdo
    let analysis = "Documento processado com sucesso."

    if (process.env.OPENAI_API_KEY && textForAnalysis.trim()) {
      try {
        const response = await fetch("https://api.openai.com/v1/chat/completions", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model: "gpt-4o",
            messages: [
              {
                role: "system",
                content:
                  "Você é um assistente especializado em análise de documentos. Analise o texto fornecido e forneça um resumo útil, identificando tópicos principais, tipo de documento e informações relevantes.",
              },
              {
                role: "user",
                content: `Analise este documento:\n\n${textForAnalysis}`,
              },
            ],
            max_tokens: 800,
            temperature: 0.3,
          }),
        })

        if (response.ok) {
          const result = await response.json()
          analysis = result.choices[0]?.message?.content || analysis
        }
      } catch (analysisError) {
        console.error("Erro na análise do documento:", analysisError)
      }
    }

    // Criar resumo
    const summary = extractedText.length > 200 ? extractedText.substring(0, 200) + "..." : extractedText

    return NextResponse.json({
      type: "document",
      analysis,
      content: extractedText,
      summary,
      info: fileInfo,
      wordCount: extractedText.split(/\s+/).length,
      characterCount: extractedText.length,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Erro na análise de documento:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
