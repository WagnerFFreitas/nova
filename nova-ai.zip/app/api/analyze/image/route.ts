import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get("file") as File

    if (!file) {
      return NextResponse.json({ error: "Nenhum arquivo enviado" }, { status: 400 })
    }

    // Verificar se é uma imagem
    if (!file.type.startsWith("image/")) {
      return NextResponse.json({ error: "Arquivo deve ser uma imagem" }, { status: 400 })
    }

    // Converter para base64
    const bytes = await file.arrayBuffer()
    const base64 = Buffer.from(bytes).toString("base64")
    const dataUrl = `data:${file.type};base64,${base64}`

    // Usar OpenAI GPT-4 Vision para análise
    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({ error: "OpenAI API key não configurada" }, { status: 500 })
    }

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4o",
        messages: [
          {
            role: "user",
            content: [
              {
                type: "text",
                text: "Analise esta imagem em detalhes. Descreva o que você vê, incluindo objetos, pessoas, cores, ambiente, emoções e qualquer texto visível. Seja descritivo e útil para alguém que não pode ver a imagem.",
              },
              {
                type: "image_url",
                image_url: {
                  url: dataUrl,
                  detail: "high",
                },
              },
            ],
          },
        ],
        max_tokens: 1000,
        temperature: 0.7,
      }),
    })

    if (!response.ok) {
      const error = await response.text()
      console.error("OpenAI Vision Error:", error)
      return NextResponse.json({ error: "Erro na análise da imagem" }, { status: response.status })
    }

    const result = await response.json()
    const analysis = result.choices[0]?.message?.content || "Não foi possível analisar a imagem"

    // Extrair informações adicionais
    const imageInfo = {
      name: file.name,
      size: file.size,
      type: file.type,
      dimensions: "Desconhecido", // Poderia usar uma biblioteca para extrair dimensões
    }

    return NextResponse.json({
      type: "image",
      analysis,
      description: analysis,
      info: imageInfo,
      summary: analysis.substring(0, 200) + "...",
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Erro na análise de imagem:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
