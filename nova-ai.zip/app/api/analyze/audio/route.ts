import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get("file") as File

    if (!file) {
      return NextResponse.json({ error: "Nenhum arquivo enviado" }, { status: 400 })
    }

    // Verificar se é um arquivo de áudio
    if (!file.type.startsWith("audio/")) {
      return NextResponse.json({ error: "Arquivo deve ser de áudio" }, { status: 400 })
    }

    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({ error: "OpenAI API key não configurada" }, { status: 500 })
    }

    // Preparar FormData para OpenAI Whisper
    const whisperFormData = new FormData()
    whisperFormData.append("file", file)
    whisperFormData.append("model", "whisper-1")
    whisperFormData.append("language", "pt")
    whisperFormData.append("response_format", "verbose_json")

    // Transcrever com OpenAI Whisper
    const transcriptionResponse = await fetch("https://api.openai.com/v1/audio/transcriptions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
      },
      body: whisperFormData,
    })

    if (!transcriptionResponse.ok) {
      const error = await transcriptionResponse.text()
      console.error("OpenAI Whisper Error:", error)
      return NextResponse.json({ error: "Erro na transcrição do áudio" }, { status: transcriptionResponse.status })
    }

    const transcriptionResult = await transcriptionResponse.json()
    const transcription = transcriptionResult.text || ""
    const duration = transcriptionResult.duration || 0
    const segments = transcriptionResult.segments || []

    // Analisar o conteúdo transcrito
    let analysis = "Áudio transcrito com sucesso."

    if (transcription.trim()) {
      try {
        const analysisResponse = await fetch("https://api.openai.com/v1/chat/completions", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model: "gpt-4o",
            messages: [
              {
                role: "system",
                content:
                  "Você é um assistente especializado em análise de áudio transcrito. Analise o texto fornecido e forneça um resumo útil, identificando tópicos principais, sentimentos, e informações relevantes.",
              },
              {
                role: "user",
                content: `Analise esta transcrição de áudio:\n\n${transcription}`,
              },
            ],
            max_tokens: 600,
            temperature: 0.3,
          }),
        })

        if (analysisResponse.ok) {
          const result = await analysisResponse.json()
          analysis = result.choices[0]?.message?.content || analysis
        }
      } catch (analysisError) {
        console.error("Erro na análise da transcrição:", analysisError)
      }
    }

    // Informações do arquivo
    const audioInfo = {
      name: file.name,
      size: file.size,
      type: file.type,
      duration: Math.round(duration),
      segments: segments.length,
    }

    // Criar resumo
    const summary = transcription.length > 200 ? transcription.substring(0, 200) + "..." : transcription

    return NextResponse.json({
      type: "audio",
      analysis,
      transcription,
      summary,
      info: audioInfo,
      duration: Math.round(duration),
      wordCount: transcription.split(/\s+/).length,
      segments: segments.map((seg: any) => ({
        start: seg.start,
        end: seg.end,
        text: seg.text,
      })),
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Erro na análise de áudio:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
