"use client"

import type React from "react"

import { useState, useRef, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Upload, X, FileText, ImageIcon, Music, Video, File, Camera, Mic, Check, AlertCircle } from "lucide-react"
import { cn } from "@/lib/utils"

interface FileUploadProps {
  onFilesUploaded: (files: UploadedFile[]) => void
  onFileAnalyzed: (fileId: string, analysis: any) => void
  maxFiles?: number
  maxSize?: number // MB
  className?: string
}

interface UploadedFile {
  id: string
  name: string
  size: number
  type: string
  file: File
  preview?: string
  status: "uploading" | "analyzing" | "completed" | "error"
  progress: number
  analysis?: any
  error?: string
}

const ACCEPTED_TYPES = {
  image: ["image/jpeg", "image/png", "image/gif", "image/webp"],
  document: [
    "application/pdf",
    "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "text/plain",
  ],
  audio: ["audio/mpeg", "audio/wav", "audio/m4a", "audio/ogg"],
  video: ["video/mp4", "video/avi", "video/mov", "video/webm"],
}

export default function FileUpload({
  onFilesUploaded,
  onFileAnalyzed,
  maxFiles = 5,
  maxSize = 25,
  className,
}: FileUploadProps) {
  const [files, setFiles] = useState<UploadedFile[]>([])
  const [isDragging, setIsDragging] = useState(false)
  const [isCapturing, setIsCapturing] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const [recordingTime, setRecordingTime] = useState(0)
  const recordingIntervalRef = useRef<NodeJS.Timeout | null>(null)

  const getFileIcon = (type: string) => {
    if (type.startsWith("image/")) return <ImageIcon className="w-6 h-6 text-blue-500" />
    if (type.startsWith("audio/")) return <Music className="w-6 h-6 text-green-500" />
    if (type.startsWith("video/")) return <Video className="w-6 h-6 text-purple-500" />
    if (type.includes("pdf") || type.includes("document") || type.includes("text"))
      return <FileText className="w-6 h-6 text-red-500" />
    return <File className="w-6 h-6 text-gray-500" />
  }

  const getFileCategory = (type: string): keyof typeof ACCEPTED_TYPES => {
    if (ACCEPTED_TYPES.image.includes(type)) return "image"
    if (ACCEPTED_TYPES.document.includes(type)) return "document"
    if (ACCEPTED_TYPES.audio.includes(type)) return "audio"
    if (ACCEPTED_TYPES.video.includes(type)) return "video"
    return "document"
  }

  const isValidFileType = (type: string) => {
    return Object.values(ACCEPTED_TYPES).flat().includes(type)
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  const createFilePreview = (file: File): Promise<string | undefined> => {
    return new Promise((resolve) => {
      if (file.type.startsWith("image/")) {
        const reader = new FileReader()
        reader.onload = (e) => resolve(e.target?.result as string)
        reader.readAsDataURL(file)
      } else {
        resolve(undefined)
      }
    })
  }

  const analyzeFile = async (uploadedFile: UploadedFile) => {
    try {
      setFiles((prev) => prev.map((f) => (f.id === uploadedFile.id ? { ...f, status: "analyzing", progress: 50 } : f)))

      const formData = new FormData()
      formData.append("file", uploadedFile.file)

      const category = getFileCategory(uploadedFile.type)
      let endpoint = "/api/analyze/document"

      if (category === "image") endpoint = "/api/analyze/image"
      else if (category === "audio") endpoint = "/api/analyze/audio"

      const response = await fetch(endpoint, {
        method: "POST",
        body: formData,
      })

      if (!response.ok) {
        throw new Error(`Erro na análise: ${response.statusText}`)
      }

      const analysis = await response.json()

      setFiles((prev) =>
        prev.map((f) => (f.id === uploadedFile.id ? { ...f, status: "completed", progress: 100, analysis } : f)),
      )

      onFileAnalyzed(uploadedFile.id, analysis)
    } catch (error) {
      console.error("Erro ao analisar arquivo:", error)
      setFiles((prev) =>
        prev.map((f) =>
          f.id === uploadedFile.id
            ? {
                ...f,
                status: "error",
                progress: 0,
                error: error instanceof Error ? error.message : "Erro desconhecido",
              }
            : f,
        ),
      )
    }
  }

  const processFiles = async (fileList: FileList | File[]) => {
    const newFiles: UploadedFile[] = []

    for (let i = 0; i < fileList.length && files.length + newFiles.length < maxFiles; i++) {
      const file = fileList instanceof FileList ? fileList[i] : fileList[i]

      if (!isValidFileType(file.type)) {
        continue
      }

      if (file.size > maxSize * 1024 * 1024) {
        continue
      }

      const preview = await createFilePreview(file)
      const uploadedFile: UploadedFile = {
        id: Math.random().toString(36).substr(2, 9),
        name: file.name,
        size: file.size,
        type: file.type,
        file,
        preview,
        status: "uploading",
        progress: 0,
      }

      newFiles.push(uploadedFile)
    }

    if (newFiles.length > 0) {
      setFiles((prev) => [...prev, ...newFiles])
      onFilesUploaded(newFiles)

      // Simular upload e depois analisar
      for (const file of newFiles) {
        // Simular progresso de upload
        for (let progress = 0; progress <= 100; progress += 20) {
          await new Promise((resolve) => setTimeout(resolve, 100))
          setFiles((prev) => prev.map((f) => (f.id === file.id ? { ...f, progress } : f)))
        }

        // Analisar arquivo
        await analyzeFile(file)
      }
    }
  }

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      setIsDragging(false)

      const droppedFiles = Array.from(e.dataTransfer.files)
      processFiles(droppedFiles)
    },
    [files.length, maxFiles, maxSize],
  )

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }, [])

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      processFiles(e.target.files)
    }
  }

  const removeFile = (fileId: string) => {
    setFiles((prev) => prev.filter((f) => f.id !== fileId))
  }

  const startCamera = async () => {
    try {
      setIsCapturing(true)
      const stream = await navigator.mediaDevices.getUserMedia({ video: true })
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        videoRef.current.play()
      }
    } catch (error) {
      console.error("Erro ao acessar câmera:", error)
      setIsCapturing(false)
    }
  }

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const canvas = canvasRef.current
      const video = videoRef.current
      const context = canvas.getContext("2d")

      canvas.width = video.videoWidth
      canvas.height = video.videoHeight

      if (context) {
        context.drawImage(video, 0, 0)
        canvas.toBlob(
          (blob) => {
            if (blob) {
              const file = new File([blob], `foto-${Date.now()}.jpg`, { type: "image/jpeg" })
              processFiles([file])
            }
          },
          "image/jpeg",
          0.9,
        )
      }

      stopCamera()
    }
  }

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream
      stream.getTracks().forEach((track) => track.stop())
      videoRef.current.srcObject = null
    }
    setIsCapturing(false)
  }

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mediaRecorder = new MediaRecorder(stream)
      mediaRecorderRef.current = mediaRecorder

      const chunks: BlobPart[] = []

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunks.push(event.data)
        }
      }

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks, { type: "audio/webm" })
        const file = new File([blob], `gravacao-${Date.now()}.webm`, { type: "audio/webm" })
        processFiles([file])

        stream.getTracks().forEach((track) => track.stop())
        setRecordingTime(0)
        if (recordingIntervalRef.current) {
          clearInterval(recordingIntervalRef.current)
        }
      }

      mediaRecorder.start()

      recordingIntervalRef.current = setInterval(() => {
        setRecordingTime((prev) => prev + 1)
      }, 1000)
    } catch (error) {
      console.error("Erro ao iniciar gravação:", error)
    }
  }

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === "recording") {
      mediaRecorderRef.current.stop()
    }
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  return (
    <div className={cn("space-y-4", className)}>
      {/* Área de Upload */}
      <Card
        className={cn(
          "border-2 border-dashed transition-colors cursor-pointer",
          isDragging ? "border-cyan-500 bg-cyan-500/10" : "border-gray-600 hover:border-gray-500",
        )}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onClick={() => fileInputRef.current?.click()}
      >
        <div className="p-6 text-center">
          <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-200 mb-2">Arraste arquivos aqui ou clique para selecionar</h3>
          <p className="text-sm text-gray-400 mb-4">
            Suporte para imagens, documentos, áudio e vídeo (máx. {maxSize}MB cada)
          </p>

          <div className="flex flex-wrap justify-center gap-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={(e) => {
                e.stopPropagation()
                startCamera()
              }}
              className="bg-gray-800 border-gray-700"
            >
              <Camera className="w-4 h-4 mr-2" />
              Câmera
            </Button>

            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={(e) => {
                e.stopPropagation()
                if (mediaRecorderRef.current?.state === "recording") {
                  stopRecording()
                } else {
                  startRecording()
                }
              }}
              className={cn(
                "bg-gray-800 border-gray-700",
                mediaRecorderRef.current?.state === "recording" && "bg-red-900 border-red-700",
              )}
            >
              <Mic className="w-4 h-4 mr-2" />
              {mediaRecorderRef.current?.state === "recording" ? `Parar (${formatTime(recordingTime)})` : "Gravar"}
            </Button>
          </div>
        </div>
      </Card>

      {/* Modal da Câmera */}
      {isCapturing && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div className="bg-gray-800 rounded-lg p-6 max-w-md w-full">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-white">Capturar Foto</h3>
              <Button variant="ghost" size="icon" onClick={stopCamera} className="text-gray-400 hover:text-white">
                <X className="w-5 h-5" />
              </Button>
            </div>

            <div className="space-y-4">
              <video ref={videoRef} className="w-full rounded-lg" autoPlay muted />

              <div className="flex gap-2">
                <Button onClick={capturePhoto} className="flex-1 bg-cyan-700 hover:bg-cyan-600">
                  <Camera className="w-4 h-4 mr-2" />
                  Capturar
                </Button>
                <Button variant="outline" onClick={stopCamera} className="bg-gray-700 border-gray-600">
                  Cancelar
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Lista de Arquivos */}
      {files.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-sm font-medium text-gray-300">
            Arquivos ({files.length}/{maxFiles})
          </h4>

          {files.map((file) => (
            <Card key={file.id} className="p-3 bg-gray-800 border-gray-700">
              <div className="flex items-center gap-3">
                {file.preview ? (
                  <img
                    src={file.preview || "/placeholder.svg"}
                    alt={file.name}
                    className="w-10 h-10 rounded object-cover"
                  />
                ) : (
                  getFileIcon(file.type)
                )}

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-gray-200 truncate">{file.name}</p>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => removeFile(file.id)}
                      className="h-6 w-6 text-gray-400 hover:text-red-400"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>

                  <p className="text-xs text-gray-400">{formatFileSize(file.size)}</p>

                  {file.status === "uploading" || file.status === "analyzing" ? (
                    <div className="mt-2">
                      <div className="flex items-center justify-between text-xs text-gray-400 mb-1">
                        <span>{file.status === "uploading" ? "Enviando..." : "Analisando..."}</span>
                        <span>{file.progress}%</span>
                      </div>
                      <Progress value={file.progress} className="h-1" />
                    </div>
                  ) : file.status === "completed" ? (
                    <div className="flex items-center gap-1 mt-1">
                      <Check className="w-3 h-3 text-green-500" />
                      <span className="text-xs text-green-500">Analisado</span>
                    </div>
                  ) : file.status === "error" ? (
                    <div className="flex items-center gap-1 mt-1">
                      <AlertCircle className="w-3 h-3 text-red-500" />
                      <span className="text-xs text-red-500">{file.error || "Erro no processamento"}</span>
                    </div>
                  ) : null}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Input oculto */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept={Object.values(ACCEPTED_TYPES).flat().join(",")}
        onChange={handleFileSelect}
        className="hidden"
      />

      {/* Canvas oculto para captura */}
      <canvas ref={canvasRef} className="hidden" />
    </div>
  )
}
