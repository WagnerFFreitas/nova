"use client"

import { useRef, useCallback, useState, useEffect } from "react"

interface VoiceConfig {
  provider: "browser" | "elevenlabs" | "azure" | "openai"
  voiceId?: string
  model?: string
  speed: number
  pitch: number
  volume: number
}

interface NaturalVoiceProps {
  config: VoiceConfig
  onStart?: () => void
  onEnd?: () => void
  onError?: (error: Error) => void
}

export default function NaturalVoice({ config, onStart, onEnd, onError }: NaturalVoiceProps) {
  const [isSupported, setIsSupported] = useState(false)
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([])
  const [selectedVoice, setSelectedVoice] = useState<SpeechSynthesisVoice | null>(null)
  const speechSynthesisRef = useRef<SpeechSynthesis | null>(null)
  const currentUtteranceRef = useRef<SpeechSynthesisUtterance | null>(null)

  // Inicializar síntese de voz
  useEffect(() => {
    if (typeof window !== "undefined" && window.speechSynthesis) {
      speechSynthesisRef.current = window.speechSynthesis
      setIsSupported(true)

      // Carregar vozes disponíveis
      const loadVoices = () => {
        const voices = speechSynthesisRef.current?.getVoices() || []
        setAvailableVoices(voices)

        // Selecionar melhor voz feminina em português
        const bestVoice = selectBestVoice(voices)
        setSelectedVoice(bestVoice)
      }

      // Carregar vozes imediatamente e quando mudarem
      loadVoices()
      speechSynthesisRef.current.onvoiceschanged = loadVoices
    }
  }, [])

  // Selecionar a melhor voz feminina disponível
  const selectBestVoice = (voices: SpeechSynthesisVoice[]): SpeechSynthesisVoice | null => {
    // Prioridades para voz feminina natural em português
    const priorities = [
      // Vozes premium do sistema (Windows/macOS/Linux)
      (v: SpeechSynthesisVoice) =>
        v.lang.includes("pt") &&
        (v.name.includes("Francisca") || v.name.includes("Raquel")) &&
        v.name.includes("Neural"),

      // Vozes femininas brasileiras
      (v: SpeechSynthesisVoice) =>
        v.lang === "pt-BR" && (v.name.includes("Female") || v.name.includes("Feminina") || v.name.includes("Woman")),

      // Vozes femininas portuguesas
      (v: SpeechSynthesisVoice) => v.lang.includes("pt") && (v.name.includes("Female") || v.name.includes("Feminina")),

      // Qualquer voz portuguesa
      (v: SpeechSynthesisVoice) => v.lang.includes("pt"),

      // Vozes femininas em inglês (fallback)
      (v: SpeechSynthesisVoice) =>
        v.lang.includes("en") && (v.name.includes("Female") || v.name.includes("Woman") || v.name.includes("Samantha")),

      // Primeira voz disponível
      () => true,
    ]

    for (const priority of priorities) {
      const voice = voices.find(priority)
      if (voice) return voice
    }

    return voices[0] || null
  }

  // Função principal para falar texto
  const speak = useCallback(
    async (text: string): Promise<void> => {
      if (!isSupported || !speechSynthesisRef.current) {
        throw new Error("Síntese de voz não suportada")
      }

      // Cancelar fala anterior
      if (currentUtteranceRef.current) {
        speechSynthesisRef.current.cancel()
      }

      try {
        switch (config.provider) {
          case "browser":
            await speakWithBrowser(text)
            break
          case "elevenlabs":
            await speakWithElevenLabs(text)
            break
          case "azure":
            await speakWithAzure(text)
            break
          case "openai":
            await speakWithOpenAI(text)
            break
          default:
            await speakWithBrowser(text)
        }
      } catch (error) {
        onError?.(error as Error)
      }
    },
    [config, isSupported, selectedVoice],
  )

  // Síntese de voz do navegador (melhorada)
  const speakWithBrowser = useCallback(
    (text: string): Promise<void> => {
      return new Promise((resolve, reject) => {
        if (!speechSynthesisRef.current || !selectedVoice) {
          reject(new Error("Voz não disponível"))
          return
        }

        const utterance = new SpeechSynthesisUtterance(text)
        currentUtteranceRef.current = utterance

        // Configurar voz
        utterance.voice = selectedVoice
        utterance.rate = config.speed
        utterance.pitch = config.pitch
        utterance.volume = config.volume

        // Melhorias para naturalidade
        utterance.rate = Math.max(0.7, Math.min(1.3, config.speed)) // Limitar velocidade
        utterance.pitch = Math.max(0.8, Math.min(1.5, config.pitch)) // Tom mais natural

        // Eventos
        utterance.onstart = () => {
          onStart?.()
        }

        utterance.onend = () => {
          currentUtteranceRef.current = null
          onEnd?.()
          resolve()
        }

        utterance.onerror = (event) => {
          currentUtteranceRef.current = null
          onError?.(new Error(`Erro na síntese: ${event.error}`))
          reject(new Error(`Erro na síntese: ${event.error}`))
        }

        // Falar com retry em caso de falha
        try {
          speechSynthesisRef.current.speak(utterance)

          // Workaround para bug do Chrome
          setTimeout(() => {
            if (speechSynthesisRef.current?.speaking && !speechSynthesisRef.current?.pending) {
              speechSynthesisRef.current.pause()
              speechSynthesisRef.current.resume()
            }
          }, 100)
        } catch (error) {
          reject(error)
        }
      })
    },
    [selectedVoice, config, onStart, onEnd, onError],
  )

  // ElevenLabs (voz premium)
  const speakWithElevenLabs = useCallback(
    async (text: string): Promise<void> => {
      const response = await fetch("/api/voice/elevenlabs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text,
          voice_id: config.voiceId || "21m00Tcm4TlvDq8ikWAM", // Rachel
          model_id: config.model || "eleven_multilingual_v2",
          voice_settings: {
            stability: 0.5,
            similarity_boost: 0.8,
            style: 0.2,
            use_speaker_boost: true,
          },
        }),
      })

      if (!response.ok) {
        throw new Error("Erro na API ElevenLabs")
      }

      const audioBlob = await response.blob()
      const audioUrl = URL.createObjectURL(audioBlob)
      const audio = new Audio(audioUrl)

      return new Promise((resolve, reject) => {
        audio.onplay = () => onStart?.()
        audio.onended = () => {
          URL.revokeObjectURL(audioUrl)
          onEnd?.()
          resolve()
        }
        audio.onerror = () => {
          URL.revokeObjectURL(audioUrl)
          reject(new Error("Erro ao reproduzir áudio"))
        }

        audio.play().catch(reject)
      })
    },
    [config, onStart, onEnd],
  )

  // Azure Speech (empresarial)
  const speakWithAzure = useCallback(
    async (text: string): Promise<void> => {
      const response = await fetch("/api/voice/azure", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text,
          voice: config.voiceId || "pt-BR-FranciscaNeural",
          rate: config.speed,
          pitch: config.pitch,
        }),
      })

      if (!response.ok) {
        throw new Error("Erro na API Azure")
      }

      const audioBlob = await response.blob()
      const audioUrl = URL.createObjectURL(audioBlob)
      const audio = new Audio(audioUrl)

      return new Promise((resolve, reject) => {
        audio.onplay = () => onStart?.()
        audio.onended = () => {
          URL.revokeObjectURL(audioUrl)
          onEnd?.()
          resolve()
        }
        audio.onerror = () => {
          URL.revokeObjectURL(audioUrl)
          reject(new Error("Erro ao reproduzir áudio"))
        }

        audio.play().catch(reject)
      })
    },
    [config, onStart, onEnd],
  )

  // OpenAI TTS (como ChatGPT)
  const speakWithOpenAI = useCallback(
    async (text: string): Promise<void> => {
      const response = await fetch("/api/voice/openai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          input: text,
          model: config.model || "tts-1-hd",
          voice: config.voiceId || "nova", // Voz feminina natural
          response_format: "mp3",
          speed: config.speed,
        }),
      })

      if (!response.ok) {
        throw new Error("Erro na API OpenAI TTS")
      }

      const audioBlob = await response.blob()
      const audioUrl = URL.createObjectURL(audioBlob)
      const audio = new Audio(audioUrl)

      return new Promise((resolve, reject) => {
        audio.onplay = () => onStart?.()
        audio.onended = () => {
          URL.revokeObjectURL(audioUrl)
          onEnd?.()
          resolve()
        }
        audio.onerror = () => {
          URL.revokeObjectURL(audioUrl)
          reject(new Error("Erro ao reproduzir áudio"))
        }

        audio.play().catch(reject)
      })
    },
    [config, onStart, onEnd],
  )

  // Parar fala atual
  const stop = useCallback(() => {
    if (speechSynthesisRef.current) {
      speechSynthesisRef.current.cancel()
    }
    currentUtteranceRef.current = null
  }, [])

  // Verificar se está falando
  const isSpeaking = useCallback(() => {
    return speechSynthesisRef.current?.speaking || false
  }, [])

  return {
    speak,
    stop,
    isSpeaking,
    isSupported,
    availableVoices,
    selectedVoice,
  }
}

// Hook para usar a voz natural
export function useNaturalVoice(config: VoiceConfig) {
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [error, setError] = useState<Error | null>(null)

  const voiceConfig = {
    ...config,
    onStart: () => setIsSpeaking(true),
    onEnd: () => setIsSpeaking(false),
    onError: (err: Error) => {
      setError(err)
      setIsSpeaking(false)
    },
  }

  const voice = NaturalVoice(voiceConfig)

  return {
    ...voice,
    isSpeaking,
    error,
    clearError: () => setError(null),
  }
}
