import AriaInterface from "@/components/aria-interface"

export default function Home() {
  return <AriaInterface />
}

