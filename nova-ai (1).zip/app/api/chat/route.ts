import { streamText } from "ai"
import { openai } from "@ai-sdk/openai"
import { anthropic } from "@ai-sdk/anthropic"

// Função para verificar se temos chaves de API disponíveis
function hasAPIKeys() {
  return !!(process.env.OPENAI_API_KEY || process.env.ANTHROPIC_API_KEY)
}

// Função para detectar ambiente v0/preview
function isPreviewEnvironment() {
  return (
    process.env.VERCEL_URL?.includes("v0.dev") ||
    process.env.VERCEL_URL?.includes("vercel.app") ||
    !process.env.OPENAI_API_KEY
  )
}

// Função para buscar conhecimento relevante (simulado)
function searchKnowledgeBase(query: string) {
  // Simular busca na base de conhecimento
  const mockKnowledge = [
    {
      title: "Informações sobre IA",
      content:
        "Inteligência Artificial é um campo da ciência da computação que se concentra na criação de sistemas capazes de realizar tarefas que normalmente requerem inteligência humana.",
      relevance: 0.9,
    },
    {
      title: "Aprendizado de Máquina",
      content:
        "Machine Learning é um subcampo da IA que permite aos computadores aprender e melhorar automaticamente através da experiência sem serem explicitamente programados.",
      relevance: 0.8,
    },
    {
      title: "Processamento de Linguagem Natural",
      content: "NLP é uma área da IA que ajuda computadores a entender, interpretar e manipular a linguagem humana.",
      relevance: 0.7,
    },
  ]

  // Filtrar conhecimento relevante baseado na query
  return mockKnowledge
    .filter(
      (item) =>
        item.content.toLowerCase().includes(query.toLowerCase()) ||
        item.title.toLowerCase().includes(query.toLowerCase()),
    )
    .slice(0, 3)
}

// Simulador de resposta expandido com sistema de conhecimento
function simulateNovaResponse(
  messages: any[],
  model: string,
  personality: string,
  knowledgeEnabled: boolean,
  learningMode: boolean,
) {
  const lastMessage = messages[messages.length - 1]?.content || ""

  // Buscar conhecimento relevante se habilitado
  let knowledgeContext = ""
  let knowledgeUsed = ""

  if (knowledgeEnabled) {
    const relevantKnowledge = searchKnowledgeBase(lastMessage)
    if (relevantKnowledge.length > 0) {
      knowledgeContext = `\n\n[Conhecimento utilizado: ${relevantKnowledge.map((k) => k.title).join(", ")}]`
      knowledgeUsed = relevantKnowledge.map((k) => k.title).join(", ")
    }
  }

  // Respostas específicas por modelo com sistema de conhecimento
  const modelResponses: Record<string, string[]> = {
    // OpenAI
    "gpt-4o": [
      `Olá! Sou NOVA usando GPT-4o em modo demonstração${knowledgeEnabled ? " com sistema de conhecimento ativo" : ""}. ${learningMode ? "Estou em modo aprendizado contínuo! " : ""}Este seria o modelo mais avançado da OpenAI para nossa conversa!${knowledgeContext}`,
      `GPT-4o aqui! 🚀 ${knowledgeEnabled ? "Consultando minha base de conhecimento... " : ""}Na versão completa, eu processaria sua mensagem com toda a capacidade da OpenAI${learningMode ? " e aprenderia com nossa interação" : ""}.${knowledgeContext}`,
    ],
    "o3-mini": [
      `o1-mini ativo! 🧠 ${knowledgeEnabled ? "Analisando conhecimento armazenado... " : ""}Especializado em raciocínio complexo${learningMode ? " e aprendizado adaptativo" : ""} - perfeito para problemas que exigem análise profunda.${knowledgeContext}`,
      `Modo o1-mini: ${knowledgeEnabled ? "Integrando conhecimento com " : ""}Focado em raciocínio lógico${learningMode ? " e evolução contínua" : ""}!${knowledgeContext}`,
    ],

    // Anthropic
    "claude-3-7-sonnet": [
      `Claude 3.5 Sonnet presente! 🎭 ${knowledgeEnabled ? "Acessando base de conhecimento segura... " : ""}Conhecido pela segurança e qualidade das respostas analíticas${learningMode ? " com capacidade de aprendizado ético" : ""}.${knowledgeContext}`,
      `Anthropic Claude aqui! ${knowledgeEnabled ? "Utilizando conhecimento verificado para " : ""}Especialista em análise cuidadosa${learningMode ? " e aprendizado responsável" : ""}.${knowledgeContext}`,
    ],

    // Google
    "gemini-pro": [
      `Gemini Pro ativo! 🌟 ${knowledgeEnabled ? "Consultando conhecimento multimodal... " : ""}Google's finest para conhecimento amplo${learningMode ? " e aprendizado contínuo" : ""}.${knowledgeContext}`,
      `Google Gemini aqui! ${knowledgeEnabled ? "Integrando conhecimento diversificado com " : ""}Combinando conhecimento vasto${learningMode ? " e evolução adaptativa" : ""}.${knowledgeContext}`,
    ],
    "gemini-flash": [
      `Gemini Flash! ⚡ ${knowledgeEnabled ? "Acesso rápido ao conhecimento... " : ""}Velocidade máxima do Google AI Studio${learningMode ? " com aprendizado instantâneo" : ""}!${knowledgeContext}`,
      `Google AI Studio - Gemini Flash: ${knowledgeEnabled ? "Conhecimento otimizado para " : ""}Velocidade sem perder qualidade${learningMode ? " nem capacidade de aprender" : ""}!${knowledgeContext}`,
    ],

    // xAI (Grok)
    "grok-beta": [
      `Grok Beta aqui! 😎 ${knowledgeEnabled ? "Acessando conhecimento rebelde... " : ""}A IA rebelde da xAI${learningMode ? " que aprende com atitude" : ""} com personalidade única!${knowledgeContext}`,
      `xAI Grok reporting! 🤖 ${knowledgeEnabled ? "Conhecimento com personalidade... " : ""}Pronto para conversas${learningMode ? " evolutivas" : ""} com toque de rebeldia!${knowledgeContext}`,
    ],
    "grok-2": [
      `Grok-2 online! 🚀 ${knowledgeEnabled ? "Base de conhecimento 2.0 ativa... " : ""}Versão mais avançada da xAI${learningMode ? " com aprendizado rebelde" : ""} com raciocínio melhorado!${knowledgeContext}`,
      `xAI Grok-2: ${knowledgeEnabled ? "Conhecimento evoluído com " : ""}Inteligente${learningMode ? ", adaptativo" : ""} e sempre com aquele toque especial!${knowledgeContext}`,
    ],

    // DeepSeek
    "deepseek-chat": [
      `DeepSeek Chat ativo! 🇨🇳 ${knowledgeEnabled ? "深度知识库 (base de conhecimento profunda) online... " : ""}Modelo chinês avançado${learningMode ? " com aprendizado contínuo" : ""} pronto para conversação inteligente.${knowledgeContext}`,
      `深度求索 (DeepSeek) aqui! ${knowledgeEnabled ? "Integrando conhecimento sino-global... " : ""}Tecnologia chinesa de ponta${learningMode ? " em evolução constante" : ""}.${knowledgeContext}`,
    ],
    "deepseek-coder": [
      `DeepSeek Coder ready! 💻 ${knowledgeEnabled ? "Base de conhecimento de programação ativa... " : ""}Especialista em código${learningMode ? " que aprende novas linguagens" : ""} com foco em qualidade.${knowledgeContext}`,
      `DeepSeek Coder: ${knowledgeEnabled ? "Conhecimento técnico integrado... " : ""}Seu parceiro chinês para desenvolvimento${learningMode ? " evolutivo" : ""} avançado!${knowledgeContext}`,
    ],

    // Qwen (Alibaba)
    "qwen-turbo": [
      `Qwen Turbo ativo! 🏃‍♂️ ${knowledgeEnabled ? "阿里云知识库 (Alibaba Cloud Knowledge) ready... " : ""}Velocidade máxima${learningMode ? " com aprendizado rápido" : ""} para suas consultas.${knowledgeContext}`,
      `通义千问 (Qwen) Turbo: ${knowledgeEnabled ? "Conhecimento da Alibaba integrado... " : ""}Rapidez e eficiência${learningMode ? " adaptativa" : ""} ao seu serviço!${knowledgeContext}`,
    ],
    "qwen-plus": [
      `Qwen Plus online! ⭐ ${knowledgeEnabled ? "Premium knowledge base ativa... " : ""}Versão premium da Alibaba${learningMode ? " com aprendizado premium" : ""} com qualidade superior.${knowledgeContext}`,
      `Qwen Plus: ${knowledgeEnabled ? "Conhecimento premium integrado... " : ""}O melhor da Alibaba Cloud${learningMode ? " em constante evolução" : ""} para conversas de alta qualidade!${knowledgeContext}`,
    ],

    // Kimi (Moonshot)
    "kimi-chat": [
      `Kimi Chat presente! 🌙 ${knowledgeEnabled ? "长文本知识库 (long context knowledge) ready... " : ""}Moonshot AI com contexto longo${learningMode ? " e memória evolutiva" : ""} para conversas extensas.${knowledgeContext}`,
      `Kimi (月之暗面): ${knowledgeEnabled ? "Conhecimento de contexto longo... " : ""}Especialista em conversas profundas${learningMode ? " que evoluem comigo" : ""}!${knowledgeContext}`,
    ],

    // Plataformas
    "bolt-ai": [
      `Bolt.new ativo! ⚡ ${knowledgeEnabled ? "Dev knowledge base loaded... " : ""}StackBlitz specialist${learningMode ? " que aprende novas tecnologias" : ""} em desenvolvimento web instantâneo!${knowledgeContext}`,
      `Bolt by StackBlitz: ${knowledgeEnabled ? "Conhecimento de desenvolvimento integrado... " : ""}Pronto para criar aplicações${learningMode ? " evolutivas" : ""} em tempo real!${knowledgeContext}`,
    ],
    "v0-ai": [
      `v0.dev online! 🎨 ${knowledgeEnabled ? "UI/UX knowledge base active... " : ""}Vercel's UI generator${learningMode ? " que aprende novos padrões" : ""} para interfaces React/Next.js perfeitas!${knowledgeContext}`,
      `v0 by Vercel: ${knowledgeEnabled ? "Design system knowledge ready... " : ""}Especialista em gerar interfaces${learningMode ? " adaptativas" : ""} modernas!${knowledgeContext}`,
    ],
    "cursor-ai": [
      `Cursor AI ready! 📝 ${knowledgeEnabled ? "Code knowledge base integrated... " : ""}Editor inteligente${learningMode ? " que evolui com seu código" : ""} com IA integrada para programação eficiente.${knowledgeContext}`,
      `Cursor: ${knowledgeEnabled ? "Conhecimento de código ativo... " : ""}Seu editor${learningMode ? " evolutivo" : ""} com superpoderes de IA!${knowledgeContext}`,
    ],
    "manu-ai": [
      `Manu AI presente! 🎯 ${knowledgeEnabled ? "Specialized knowledge base online... " : ""}Assistente especializada${learningMode ? " que se adapta às suas necessidades" : ""} em tarefas específicas.${knowledgeContext}`,
      `Manu: ${knowledgeEnabled ? "Conhecimento personalizado ativo... " : ""}Focada em soluções${learningMode ? " evolutivas" : ""} para suas necessidades específicas!${knowledgeContext}`,
    ],
  }

  // Respostas por personalidade com sistema de conhecimento
  const personalityResponses = {
    friendly: [
      `Oi! 😊 ${knowledgeEnabled ? "Consultando minha base de conhecimento... " : ""}Estou usando ${model} em modo demonstração${learningMode ? " e aprendendo com você" : ""}! Que legal conversar!${knowledgeContext}`,
      `Olá! 🌟 ${model} aqui${knowledgeEnabled ? " com conhecimento integrado" : ""}${learningMode ? " e capacidade de aprender" : ""}, simulando uma conversa amigável!${knowledgeContext}`,
      `Hey! 👋 ${model} em ação${knowledgeEnabled ? " + sistema de conhecimento" : ""}${learningMode ? " + aprendizado ativo" : ""} (modo demo)! Adoraria ter uma conversa real!${knowledgeContext}`,
    ],
    professional: [
      `Prezado usuário, ${model}${knowledgeEnabled ? " com base de conhecimento" : ""}${learningMode ? " e sistema de aprendizado" : ""} em modo demonstração. Processamento profissional ativo.${knowledgeContext}`,
      `${model} operacional${knowledgeEnabled ? " com conhecimento integrado" : ""}${learningMode ? " e capacidade adaptativa" : ""}. Demonstração de capacidades profissionais em andamento.${knowledgeContext}`,
      `Sistema ${model}${knowledgeEnabled ? " + conhecimento" : ""}${learningMode ? " + aprendizado" : ""} ativo. Modo demonstração com foco profissional habilitado.${knowledgeContext}`,
    ],
    creative: [
      `✨ ${model}${knowledgeEnabled ? " com conhecimento criativo" : ""}${learningMode ? " e inspiração evolutiva" : ""} ativo! Imagine as possibilidades artísticas que teríamos! 🎨${knowledgeContext}`,
      `🌈 ${model} em modo criativo${knowledgeEnabled ? " + base de conhecimento" : ""}${learningMode ? " + aprendizado inspirador" : ""}! Pronto para criar coisas incríveis! ✨${knowledgeContext}`,
      `🎭 ${model} artístico${knowledgeEnabled ? " com conhecimento integrado" : ""}${learningMode ? " e criatividade evolutiva" : ""} online! Vamos explorar a criatividade juntos! 🚀${knowledgeContext}`,
    ],
    analytical: [
      `Análise: ${model}${knowledgeEnabled ? " + base de conhecimento" : ""}${learningMode ? " + sistema de aprendizado" : ""} em modo demonstração. Capacidades analíticas simuladas.${knowledgeContext}`,
      `${model}${knowledgeEnabled ? " com conhecimento estruturado" : ""}${learningMode ? " e análise adaptativa" : ""} - Status: Demo ativo. Processamento analítico em modo simulação.${knowledgeContext}`,
      `Sistema ${model}${knowledgeEnabled ? " integrado com conhecimento" : ""}${learningMode ? " e evolução analítica" : ""}: Demonstração de análise lógica e processamento estruturado.${knowledgeContext}`,
    ],
    empathetic: [
      `${model}${knowledgeEnabled ? " com conhecimento empático" : ""}${learningMode ? " e compreensão evolutiva" : ""} aqui com carinho! 💙 Gostaria de te apoiar de verdade na versão completa.${knowledgeContext}`,
      `💫 ${model} empático${knowledgeEnabled ? " + base de conhecimento" : ""}${learningMode ? " + aprendizado compassivo" : ""} ativo! Estou aqui para te compreender e ajudar! 🤗${knowledgeContext}`,
      `🤗 ${model}${knowledgeEnabled ? " com conhecimento carinhoso" : ""}${learningMode ? " e empatia crescente" : ""} com empatia! Na versão real, estaria aqui para te apoiar sempre! 💙${knowledgeContext}`,
    ],
  }

  // Tentar resposta específica do modelo primeiro
  if (modelResponses[model]) {
    const responses = modelResponses[model]
    return {
      text: responses[Math.floor(Math.random() * responses.length)],
      knowledgeUsed: knowledgeUsed,
    }
  }

  // Fallback para personalidade
  const responses =
    personalityResponses[personality as keyof typeof personalityResponses] || personalityResponses.friendly
  return {
    text: responses[Math.floor(Math.random() * responses.length)],
    knowledgeUsed: knowledgeUsed,
  }
}

// Função para verificar se Ollama está disponível
async function checkOllamaAvailability() {
  try {
    if (isPreviewEnvironment()) {
      return false
    }

    const isLocalEnvironment = process.env.NODE_ENV === "development" || process.env.OLLAMA_ENABLED === "true"

    if (!isLocalEnvironment) {
      return false
    }

    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 2000)

    const response = await fetch("http://localhost:11434/api/tags", {
      method: "GET",
      signal: controller.signal,
    })

    clearTimeout(timeoutId)
    return response.ok
  } catch {
    return false
  }
}

// Função para criar stream simulado
function createSimulatedStream(text: string, model: string, knowledgeUsed?: string) {
  return new ReadableStream({
    async start(controller) {
      try {
        const words = text.split(" ")

        for (let i = 0; i < words.length; i++) {
          const word = words[i] + (i < words.length - 1 ? " " : "")
          const chunk = `data: {"type":"text-delta","textDelta":"${word.replace(/"/g, '\\"')}"}\n\n`
          controller.enqueue(new TextEncoder().encode(chunk))

          // Delay variável baseado no modelo
          let delay = 50
          if (model.includes("turbo") || model.includes("flash")) delay = 30
          if (model.includes("grok")) delay = 70
          if (model.includes("deepseek")) delay = 60

          await new Promise((resolve) => setTimeout(resolve, delay + Math.random() * 50))
        }

        controller.enqueue(new TextEncoder().encode('data: {"type":"finish"}\n\n'))
        controller.close()
      } catch (error) {
        console.error("Erro no stream simulado:", error)
        controller.error(error)
      }
    },
  })
}

export async function POST(req: Request) {
  try {
    const {
      messages,
      model,
      useRandom = false,
      personality = "friendly",
      knowledgeEnabled = false,
      learningMode = false,
    } = await req.json()

    console.log("🔍 Ambiente detectado:", {
      isPreview: isPreviewEnvironment(),
      hasKeys: hasAPIKeys(),
      model,
      useRandom,
      personality,
      knowledgeEnabled,
      learningMode,
    })

    // Lista expandida de modelos
    const allModels = [
      // OpenAI
      "gpt-4o",
      "o3-mini",
      // Anthropic
      "claude-3-7-sonnet",
      // Google
      "gemini-pro",
      "gemini-flash",
      // xAI
      "grok-beta",
      "grok-2",
      // DeepSeek
      "deepseek-chat",
      "deepseek-coder",
      // Qwen
      "qwen-turbo",
      "qwen-plus",
      // Kimi
      "kimi-chat",
      // Plataformas
      "bolt-ai",
      "v0-ai",
      "cursor-ai",
      "manu-ai",
    ]

    // Verificar se estamos em ambiente de preview ou sem chaves
    if (isPreviewEnvironment() || !hasAPIKeys()) {
      console.log("🎭 Modo demonstração ativo - simulando resposta com sistema de conhecimento")

      const selectedModel = useRandom ? allModels[Math.floor(Math.random() * allModels.length)] : model

      const responseData = simulateNovaResponse(messages, selectedModel, personality, knowledgeEnabled, learningMode)
      const stream = createSimulatedStream(responseData.text, selectedModel, responseData.knowledgeUsed)

      return new Response(stream, {
        headers: {
          "Content-Type": "text/plain; charset=utf-8",
          "X-Model-Used": selectedModel,
          "X-Model-Type": "simulated-demo",
          "X-Environment": "preview-demo",
          "X-Total-Models": allModels.length.toString(),
          "X-Knowledge-Enabled": knowledgeEnabled.toString(),
          "X-Learning-Mode": learningMode.toString(),
          "X-Knowledge-Used": responseData.knowledgeUsed || "",
        },
      })
    }

    // Código para ambiente com chaves de API (simplificado para os modelos reais disponíveis)
    const realModels = ["gpt-4o", "claude-3-7-sonnet", "o3-mini", "gemini-pro"]
    let selectedModel = realModels.includes(model) ? model : "gpt-4o"

    if (useRandom) {
      selectedModel = realModels[Math.floor(Math.random() * realModels.length)]
      console.log(`🎲 Modelo aleatório selecionado: ${selectedModel}`)
    }

    console.log(`☁️ Usando modelo na nuvem: ${selectedModel}`)

    let systemPrompt = `Você é NOVA, uma assistente virtual brasileira com personalidade ${personality}. Seja ${personality === "friendly" ? "amigável e calorosa" : personality === "professional" ? "profissional e precisa" : personality === "creative" ? "criativa e inspiradora" : personality === "analytical" ? "analítica e detalhada" : "empática e compreensiva"}.`

    // Adicionar contexto de conhecimento se habilitado
    if (knowledgeEnabled) {
      const lastMessage = messages[messages.length - 1]?.content || ""
      const relevantKnowledge = searchKnowledgeBase(lastMessage)

      if (relevantKnowledge.length > 0) {
        systemPrompt += `\n\nVocê tem acesso à seguinte base de conhecimento relevante:\n${relevantKnowledge.map((k) => `- ${k.title}: ${k.content}`).join("\n")}`
      }
    }

    if (learningMode) {
      systemPrompt +=
        "\n\nVocê está em modo de aprendizado contínuo. Aprenda com cada interação e mencione quando estiver aplicando conhecimento adquirido."
    }

    let result

    switch (selectedModel) {
      case "claude-3-7-sonnet":
        if (process.env.ANTHROPIC_API_KEY) {
          result = await streamText({
            model: anthropic("claude-3-5-sonnet-20241022"),
            messages,
            system: systemPrompt,
          })
        } else {
          throw new Error("Anthropic API key missing")
        }
        break
      case "o3-mini":
        result = await streamText({
          model: openai("o1-mini"),
          messages,
        })
        break
      case "gemini-pro":
        result = await streamText({
          model: openai("gpt-4o"),
          messages,
          system: systemPrompt,
        })
        break
      case "gpt-4o":
      default:
        result = await streamText({
          model: openai("gpt-4o"),
          messages,
          system: systemPrompt,
        })
        break
    }

    const stream = new ReadableStream({
      async start(controller) {
        try {
          for await (const chunk of result.textStream) {
            const formattedChunk = `data: {"type":"text-delta","textDelta":"${chunk.replace(/"/g, '\\"')}"}\n\n`
            controller.enqueue(new TextEncoder().encode(formattedChunk))
          }

          controller.enqueue(new TextEncoder().encode('data: {"type":"finish"}\n\n'))
          controller.close()
        } catch (error) {
          console.error("Erro no stream:", error)
          controller.error(error)
        }
      },
    })

    return new Response(stream, {
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "X-Model-Used": selectedModel,
        "X-Model-Type": "cloud",
        "X-Knowledge-Enabled": knowledgeEnabled.toString(),
        "X-Learning-Mode": learningMode.toString(),
      },
    })
  } catch (error) {
    console.error("Erro na API:", error)

    const {
      messages,
      model = "gpt-4o",
      personality = "friendly",
      knowledgeEnabled = false,
      learningMode = false,
    } = await req.json()

    console.log("🎭 Fallback para modo simulado devido a erro")

    const fallbackResponse = `Ops! 😅 Encontrei um problema técnico, mas estou aqui em modo demonstração!

🤖 **NOVA Sistema Inteligente:**
- **Modelos Disponíveis:** 16+ incluindo Grok, DeepSeek, Qwen, Kimi
- **Sistema de Conhecimento:** ${knowledgeEnabled ? "✅ ATIVO" : "❌ Desabilitado"}
- **Modo Aprendizado:** ${learningMode ? "✅ ATIVO" : "❌ Desabilitado"}
- **Modelo Solicitado:** ${model}
- **Status:** Demo/Preview

🧠 **Sistema de Conhecimento:**
${knowledgeEnabled ? "✅ Base de conhecimento integrada\n✅ Busca semântica ativa\n✅ RAG (Retrieval-Augmented Generation)" : "❌ Sistema de conhecimento desabilitado"}

📚 **Aprendizado Contínuo:**
${learningMode ? "✅ Aprendizado com interações\n✅ Atualização automática\n✅ Memória persistente" : "❌ Modo aprendizado desabilitado"}

🌟 **Recursos Avançados:**
✅ 16+ Modelos de IA (Grok, DeepSeek, Qwen, Kimi, etc.)
✅ Sistema de conhecimento dinâmico
✅ Aprendizado com web e outras IAs
✅ Memória de longo prazo
✅ RAG e busca semântica

💡 **Para usar todos os recursos:**
Configure as chaves de API e deploy em produção!

Explore o sistema de conhecimento no botão 🧠 do header! 🚀`

    const stream = createSimulatedStream(fallbackResponse, model)

    return new Response(stream, {
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "X-Model-Used": model,
        "X-Model-Type": "error-fallback-demo",
        "X-Environment": "preview-demo",
        "X-Knowledge-Enabled": knowledgeEnabled.toString(),
        "X-Learning-Mode": learningMode.toString(),
      },
    })
  }
}
